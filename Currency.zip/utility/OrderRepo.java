package com.capgemin.Currency.utility;

import java.util.Map;
import java.util.TreeMap;

import com.capgemin.Currency.bean.Order;
/**
 * @author lavanga
 *@version 1.0 This is a repositary class for giving inputs
 */

public class OrderRepo {

	private static Map<Integer, Order> orders = new TreeMap<Integer, Order>();

	static {

		orders.put(111, new Order(111, 650, 2, 1218.75,0.0125));
		orders.put(222, new Order(222,25,5, 117.1875,0.0125));
		
	}
	
	public static Map<Integer, Order> getOrders() {
		return orders;
	}

	public static void setOrders(Map<Integer, Order> orders) {
		OrderRepo.orders = orders;
	}

}
