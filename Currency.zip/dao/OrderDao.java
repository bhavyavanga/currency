package com.capgemin.Currency.dao;

import java.util.Map;

import com.capgemin.Currency.bean.Order;
import com.capgemin.Currency.exception.OrderException;

/**
 * @author lavanga
 *@version 1.0 This is an interface for dao layer
 */

public interface OrderDao {
	
int calculateOrder(Order bean) throws OrderException;
public Map<Integer, Order> getAllOrders() throws OrderException;
public int addProductDetails(Order bean);
}
