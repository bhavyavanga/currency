package com.capgemin.Currency.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemin.Currency.bean.Order;
import com.capgemin.Currency.exception.OrderException;
import com.capgemin.Currency.utility.OrderRepo;
/**
 * @author lavanga
 *@version 1.0 This is a Dao implementation class
 */


public class OrderDaoImpl implements OrderDao {
Map<Integer, Order> currencies=OrderRepo.getOrders();
	@Override
	public int calculateOrder(Order bean) throws OrderException {
		// TODO Auto-generated method stub
		
		int amount=0;
		double conversionCharges=0.0125;
		double Amount=(bean.getPrice()*bean.getQuantity()*75);
		double conversion=(Amount*conversionCharges);
		amount=(int) Amount + (int)conversion;
		return amount;
		
	}

	@Override
	public Map<Integer, Order> getAllOrders() throws OrderException {
		
		return currencies;
	}

	@Override
	public int addProductDetails(Order bean) {
		int productId=(int)(Math.random()*1000);
		currencies.put(productId, bean);
		return productId;
	}

}
