package com.capgemin.Currency.main;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemin.Currency.bean.Order;
import com.capgemin.Currency.exception.OrderException;
import com.capgemin.Currency.service.OrderService;
import com.capgemin.Currency.service.OrderServiceImpl;
/**
 * 
 * @author lavanga
 *@version 1.0 This is a MainUI class taking user inputs
 */



public class MainUI {

	public static void main(String[] args) throws OrderException {
		// TODO Auto-generated method stub

		String continueChoice;
		boolean continueValue = false;
		Scanner scanner = null;
		do {
		//printing the available options
			System.out.println("*** welcome to currency conversion");
			System.out.println("1.currencyConversion");
			System.out.println("2.display all");
			System.out.println("3.exit");
//creating a variable service to link the presentation layer to the service layer
			OrderService service = new OrderServiceImpl();
			
			int choice = 0;
			boolean choiceFlag = false;
			do {
				//taking input from the user for selecting one among the available options
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				//creating a try catch block to check whether there is any inputMismatchException
				try {
					//taking choice input from the user for switch case
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean vehicleNameFlag = false;
					switch (choice) {
					case 1:
						//taking input from user for price
							scanner = new Scanner(System.in);
							System.out.println("enter id:");
							int id=scanner.nextInt();
							System.out.println("Enter Price in dollars:");
							//taking input from user for quantity
							double price = scanner.nextDouble();
							System.out.println("Enter quantity:");
						int quantity=0;
						//creating a try-catch block for quantity validation
						try {
							quantity = scanner.nextInt();
							service.validateQuantity(quantity);
						} catch (OrderException e1) {
							// TODO Auto-generated catch block
							System.err.println(e1.getMessage());
						}
							double amount=0;
							double charges=0;
						
							
							Order order1 = new Order(id,price,quantity,amount,charges);
							//calling the service class for calculating order
							int converted= service.calculateOrder(order1);
							Order order = new Order(id,price,quantity,converted,charges);
							//calling the service class for generating id
						int genearatedId = service.addProductDetails(order);
						System.out.println("vehicle stored with the given id: " + genearatedId);
							break;
					case 2:
						//generating try-catch block for catching exceptions
						try {
							//calling service for getting all orders and storing it in a map
							Map<Integer, Order> orders = service.getAllOrders();
							//Using iterator and printing the details ina  new line
							Iterator<Integer> iterator = orders.keySet().iterator();
							while (iterator.hasNext()) {
								int id1 = iterator.next();
								Order orderData = orders.get(id1);
								System.out.println(id1 + ": " + orderData);
							}

						} catch (OrderException e) {
							System.err.println(e.getMessage());
						}
						break;
						
					case 3:
						//for stooping the entire project
						System.exit(0);

					}
				}catch (InputMismatchException exception) {
						choiceFlag = false;
						System.err.println("input should contain only digits");
					}
					}while(!choiceFlag);
					//creating a do-while loop for asking the whether to continue or not
					do {
						scanner = new Scanner(System.in);
						System.out.println("do you want to continue again [yes/no]");
						continueChoice = scanner.nextLine();
						if (continueChoice.equalsIgnoreCase("yes")) {
							continueValue = true;
							break;
						} else if (continueChoice.equalsIgnoreCase("no")) {
							System.out.println("thank you");
							continueValue = false;
							break;
						} else {
							System.out.println("enter yes or no");
							continueValue = false;
							continue;
						}
					} while (!continueValue);
		}while(continueValue);
		//closing the scanner
			scanner.close();
	}

}
