package com.capgemin.Currency.exception;
/**
 * @author lavanga
 *@version 1.0 This is an exception class for handling exceptions
 */

public class OrderException extends Exception{

	public OrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
