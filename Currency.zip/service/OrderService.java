package com.capgemin.Currency.service;

import java.util.Map;

import com.capgemin.Currency.bean.Order;
import com.capgemin.Currency.exception.OrderException;
/**
 * @author lavanga
 *@version 1.0 This is an interface for service layer
 */


public interface OrderService {

	int calculateOrder(Order bean) throws OrderException;
	public Map<Integer, Order> getAllOrders() throws OrderException;
	int addProductDetails(Order bean);
	boolean validateQuantity(int quantity) throws OrderException;
	
}
