package com.capgemin.Currency.service;

import java.util.Map;
/**
 * @author lavanga
 *@version 1.0 This is a service implementation class
 */


import com.capgemin.Currency.bean.Order;
import com.capgemin.Currency.dao.OrderDao;
import com.capgemin.Currency.dao.OrderDaoImpl;
import com.capgemin.Currency.exception.OrderException;

public class OrderServiceImpl implements OrderService {

	OrderDao orderDao = new OrderDaoImpl();
	@Override
	public int calculateOrder(Order bean) throws OrderException {
		// TODO Auto-generated method stub
		return orderDao.calculateOrder(bean);
	}

	@Override
	public Map<Integer, Order> getAllOrders() throws OrderException {
		// TODO Auto-generated method stub
		return orderDao.getAllOrders();
	}

	@Override
	public int addProductDetails(Order bean) {
		// TODO Auto-generated method stub
		return orderDao.addProductDetails(bean);
	}

	@Override
	public boolean validateQuantity(int quantity) throws OrderException {
		// TODO Auto-generated method stub
		boolean quantityFlag = false;

		if (quantity< 1) {
			throw new OrderException("quantity should not be lessthan 1");
		} else {
			quantityFlag = true;
		}
		return quantityFlag;
	}


	
}
